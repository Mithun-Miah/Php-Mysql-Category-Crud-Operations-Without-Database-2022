<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "search_data");

    $id = $_GET['idNo'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM cat_search WHERE id = $id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:search_data.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>