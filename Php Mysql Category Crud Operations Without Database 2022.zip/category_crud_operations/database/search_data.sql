-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 12:59 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `search_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `cat_search`
--

CREATE TABLE `cat_search` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `sub_category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cat_search`
--

INSERT INTO `cat_search` (`id`, `category`, `sub_category`) VALUES
(1, 'Engineering', 'Civil Engineering'),
(2, 'Chemical Engineering', 'Chemical Engineering and related technology'),
(4, 'Construction of buildings', 'Auxiliary construction practices'),
(5, 'Architecture', 'Design and decoration of structures and accessories'),
(6, 'Architecture', 'Residential and related buildings'),
(7, 'Architecture', 'Architecture'),
(8, 'Economics', 'Cooperatives'),
(9, 'Biology', 'Ecology'),
(10, 'Area planning and lanscape architecture', 'Landscape architecture (Landscape design)'),
(11, 'Chemistry', 'Chemistry and allied sciences'),
(12, 'Agriculture', 'Agriculture and related technologies'),
(13, 'Construction of Building', 'Heating, ventilating, air-conditioning engineering'),
(14, 'Earth Science and Geology', 'Geology'),
(15, 'Management and public relation', 'Accounting'),
(16, 'Science', 'Organizations and Management'),
(17, 'Agriculture', 'Garden crops (Horticulture)'),
(18, 'Chemical Engineering', 'aquatic toxicology'),
(19, 'Technology', 'hazardous materials'),
(20, 'Medicine and Health', 'technical drawing and hazardous materials'),
(21, 'Medicine and Health', 'CORROSION AND DEGRADATION'),
(22, 'Engineering', 'Applied physics for (Plastics in packaging)'),
(23, 'Construction of Building', 'Building Materials for (CLEANING STONE AND MASONRY)'),
(24, 'Engineering', 'Engineering & Applied Operations for (Joints (Engineering)--Fatigue--Congresses.)'),
(25, 'Chemical Engineering', 'Cleaning, coating, color related technology for (Coatings--Testing--Congresses.)');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cat_search`
--
ALTER TABLE `cat_search`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cat_search`
--
ALTER TABLE `cat_search`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
