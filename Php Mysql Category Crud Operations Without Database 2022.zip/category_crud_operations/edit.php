<?php

// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "search_data");

 $id = $_GET['idNo'];

 //For Show Data in Edit page input field
 $read = "SELECT * FROM cat_search WHERE id=$id";
 $query = mysqli_query($connect, $read);
 $row = mysqli_fetch_array($query);

 if(isset($_POST['edit'])){
        //$id = $_POST['id'];
        $cat = $_POST['category'];
        $sub_Cat = $_POST['sub_category'];

        $update = "UPDATE cat_search SET 
        category = '$cat', sub_category = '$sub_Cat' where id = $id ";

        $query = mysqli_query($connect, $update);

        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
 }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Edit Page</title>

    <style>
        .container{
            width: 500px;
            /* border: 1px solid black; */
            height: 400px;
            margin: 0px auto;
            text-align: center;
            padding: 10px;
        }
        h1 {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
        }
        form input {
            border: 2px solid green;
            width: 90%;
            padding: 10px;
        }
        select {
            width: 90%;
            padding: 10px;
            border: 2px solid green;
        }

        button {
            padding: 10px;
            width: 90%;
            color: white;
            background-color: green;
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 2px;
            border: none;
            cursor: pointer;
            transition: 0.2s ease-in;
        }
        button:hover {
            background-color: blue;
        }
        table,th,td{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 3px;
        }
    </style>
</head>
<body>
    <h1>Edit Data</h1>
    <div class="container">
        <a href="search_data.php"><button>Go Back</button></a>
        <br><br>
    <form method="POST">
    <!-- For Show Data in Edit page input field with value -->
            <input type="text" value="<?php echo $row['id'] ?>" name="name" placeholder="name" require> <br><br>
            <input type="text" value="<?php echo $row['category'] ?>" name="category" placeholder="category" require> <br><br>
            <input type="text" value="<?php echo $row['sub_category'] ?>" name="sub_category" placeholder="sub_category" require> <br><br>
            <br>
            <!-- <input type="submit" value="Submit"> -->
            <button name="edit">Update Data</button>
        </form>
    </div>
    
</body>
</html>