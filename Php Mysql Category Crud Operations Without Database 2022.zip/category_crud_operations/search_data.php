<?php
// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "search_data");

if(isset($_POST['add'])){
    $cat = $_POST['category'];
    $sub_Cat = $_POST['subCategory'];

    // check and data input on db
    if($cat == "" || $sub_Cat == ""){
        echo "<script>alert('Please fillup all field perfectly')</script>";
    } else {
        //"INSERT INTO TABLE_NAME (COLUMN_NAME) VALUES (VALUE)";
        $query = "INSERT INTO cat_search (category, sub_category) VALUES ('$cat', '$sub_Cat')";
        
        $insert = mysqli_query($connect, $query);

        if($insert){
            echo "<script>alert('data entry Success')</script>";
        } else{
            echo "<script>alert('Data entry Fail')</script>";
        }
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Engine</title>

    <style>
        body{
            background-color: slategray;
            margin: 0px;
            padding: 0px;
            width: 100vw;
            height: 100vh;
            box-sizing: border-box;
        }
        .container{
            width: 80vw;
            height: auto;
            margin: auto;
            text-align: center;
            border: 2px solid red;
            padding-bottom: 5px;
        }
        .heading1{
            color: white;
            font-weight: 800;
            text-shadow: 5px 5px 5px rgb(5, 5, 5);
        }
        .heading2{
            color: yellow;
            font-weight: 800;
            text-shadow: 5px 5px 5px rgb(5, 5, 5);
        }
        .searchInput{
            width: 40%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .searchBtn{
            width: 15%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.1s ease-in;
        }
        .searchBtn:hover{
            border: none;
            background-color: teal;
            color: white;
        }
        .catAdd{
            width: 30%;
            height: 25px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .subCatAdd{
            width: 30%;
            height: 25px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
        }
        .addBtn,.updateBtn,.delBtn,.clearBtn{
            width: 8%;
            height: 40px;
            padding: 5px;
            border-radius: 7px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.1s ease-in;
        }
        .addBtn:hover{
            border: none;
            background-color: teal;
            color: white;
        }
        .updateBtn:hover{
            border: none;
            background-color: darkgreen;
            color: white;
        }
        .delBtn:hover{
            border: none;
            background-color: red;
            color: white;
        }
        .clearBtn:hover{
            border: none;
            background-color: steelblue;
            color: white;
        }
        .display_data h3{
            color: #000;
            background-color: steelblue;
            padding: 10px;
            text-transform: uppercase;
            text-decoration: underline;
        }
        table{
            border: 1px solid black;
            border-collapse: collapse;
            text-align: center;
            margin: auto;
            width: 100%;
        }
        th{
            color: yellow;
            font-size: 1.2rem;
            letter-spacing: 1.5px;
        }
        td{
            color: #fff;
            font-size: 1rem;
            letter-spacing: 1.1px;
        }
        tr,th,td{
            border: 1px solid black;
            padding: 5px;
        }

    </style>
</head>
<body>

    <div class="container">
        <form action="" method="post">
            <h1 class="heading1">Add Books Category And Sub-Category</h1>
            <input type="text" name="category" placeholder="type books category" class="catAdd">
            <input type="text" name="subCategory" placeholder="type books sub-category" class="subCatAdd">
            <br><br>
            <input type="submit" name="add" value="Add" class="addBtn">
            <!-- <input type="submit" name="update" value="Update" class="updateBtn">
            <input type="submit" name="delete" value="Delete" class="delBtn"> -->
            <input type="submit" name="clear" value="Clear" class="clearBtn">
        </form>

        <div class="data_show">
            <h2 class="title2">Show Category and Sub-Category</h2>

            <form action="" method="POST">
            <input type="text" name="search" value="" placeholder="search by category or sub-category" class="searchInput">
            <!-- <input type="submit" name="submit" value="Search" class="searchBtn"> -->
            <button name="search_btn"
                style="width:10%; padding: 13px; font-size: 1.2rem;cursor: pointer;">Search</button>
            </form>

<?php
// Dynamic Page pagination

// variable to store number of rows per page
$limit = 5;  
// query to retrieve all rows from the table Countries
$getQuery = "select * from cat_search";  
// get the result
$result = mysqli_query($connect, $getQuery);  
$total_rows = mysqli_num_rows($result);
// get the required number of pages
$total_pages = ceil ($total_rows / $limit);    
// update the active page number
if (!isset ($_GET['page']) ) {  
    $page_number = 1;  
} else {  
    $page_number = $_GET['page'];  
}
// get the initial page number
$initial_page = ($page_number-1) * $limit;   

// get data of selected rows per page    
$getQuery = "SELECT * FROM cat_search LIMIT " . $initial_page . ',' . $limit;  

$result = mysqli_query($connect, $getQuery);?>
<table>
<thead>
    <tr>
        <th>SL. No.</th>
        <th>Category</th>
        <th>Sub-Category</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>
</thead>

<?php
//display the retrieved result on the webpage 
                $search_input = ""; //declear blank variable for remove error
                if(isset($_POST['search_btn'])){
                    $search_input = $_POST['search'];
                }
                $srh_query = "SELECT * FROM cat_search WHERE category LIKE '%$search_input%' OR sub_category LIKE '%$search_input%' ORDER BY id desc "; // Search and serial Number Decending Query Code";
                $run_query = mysqli_query($connect,$srh_query);

                $i = 1;

while ($row = mysqli_fetch_array($result)) {  ?>

                <tr>
                    <td><?php echo $row["id"];?></td>
                    <td><?php echo $row["category"];?></td>
                    <td><?php echo $row["sub_category"];?></td>
                    <td><a href="edit.php?idNo=<?php echo $row['id']; ?>">edit</a></td>
                    <td><a onclick="return confirm('Do You Want To Delete !')" href="delete.php?idNo=<?php echo $row['id']; ?>">delete</a></td>
                </tr>
                
                   
                <?php
                $i++;

                    }
                ?>
                <!-- After refresh/reload Data Resubmission Stop with this code -->
        <script>
            if(window.history.replaceState){
                window.history.replaceState(null,null,location.href)
            }
        </script>
                </table>  
                <br>
                <a href="pagination.php?pageno=1"> < </a> 
<?php
// show page number with link   
for($page_number = 1; $page_number<= $total_pages; $page_number++) {  
    echo '<a href = "search_data.php?page=' . $page_number . '" style="background-color:blue;color:white;padding:6px; margin:2px;border-radius:5px;">' . $page_number . ' </a>';
}

?>
                <a href="pagination.php?pageno=2"> > </a>
        </div>

        </div>
    </div>
    
</body>
</html>